
<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="log-in ptb-45">
        <div class="container">
            <div class="row">
                <!-- Returning Customer Start -->
                <div class="col-md-3 mx-auto">
               
                        <div class="card">
                          <div class="card-header bg-white">
                                <h5 class="card-title mb-0 ml-2 p-2">Menu</h5>
                          </div>
                          <ul class="list-group list-group-flush">
                            
                            <li  class="list-group-item"><a href="<?php echo e(url('patient-dashboard')); ?>" > My Orders </a></li>
                            <li  class="list-group-item"><a href="<?php echo e(url('patient-profile-settings')); ?>">Profile</a></li>
                            <li  class="list-group-item"><a href="<?php echo e(url('patient-address')); ?>">Address</a></li>
                            <li  class="list-group-item"> <a href="<?php echo e(url('change-password')); ?>">Change Password </a></li>
                            <li  class="list-group-item"><a href="<?php echo e(url('logout')); ?>">Logout</a></li>


                          </ul>
                        </div>
                </div>
                <!-- Returning Customer End -->

                <!-- Returning Customer Start -->
                
                <div class="col-md-9 mx-auto">
                    <div class="well">
                        <?php echo $__env->yieldContent('patient-content'); ?>
                    </div>
                </div>

                <!-- Returning Customer End -->
            </div>
            <!-- Row End -->
        </div>
        <!-- Container End -->
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Frontend-onlinepharmacyshop\resources\views/frontend/patient/dashboard_new.blade.php ENDPATH**/ ?>