<header>
    <!-- Header Top Start Here -->
    <div class="header-top white-bg header-top-two">
        <div class="container">
            <div class="col-sm-12">
                <div class="row justify-content-md-between justify-content-center">
                    <!-- Header Top Left Start -->
                    <div class="header-top-left">
                        <ul>
                            <?php if(!empty($pharmacy_info->contact_number_p)): ?>
                            <li class="border-right-none">
                                <i class="fa fa-phone mr-2"></i>
                                <a href="tel:<?php echo e($pharmacy_info->contact_number_p); ?>">
                                    <?php echo e($pharmacy_info->contact_number_p); ?>

                                </a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                    <!-- Header Top Left End -->
                    <!-- Header Top Right Start -->
                    <div class="header-top-right">
                        <ul>
                            <?php if(Auth::Check()): ?>
                              <li><a href="<?php echo e(asset('patient-dashboard')); ?>">My Account</a></li>
                              <li><a href="<?php echo e(asset('logout')); ?>">Logout </a></li>
                            <?php else: ?>
                               <li><a href="<?php echo e(asset('login')); ?>">Sign in</a></li>
                            <?php endif; ?>
                        </ul>
                    </div>
                    <!-- Header Top Right End -->
                </div>
            </div>
        </div>
        <!-- Container End -->
    </div>
    <!-- Header Top End Here -->
    <!-- Header Middle Start Here -->
    <div class="header-middle white-bg ptb-35">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-3 col-md-12">
                    <div class="logo mb-all-30">
                        <a href="<?php echo e(asset('/')); ?>"><img src="<?php echo e(url('storage/pharmacyprofile',$pharmacy_settings->logo_1)); ?>" alt="logo-image" class="img-fluid"></a>
                    </div>
                </div>
                <!-- Categorie Search Box Start Here -->
                <div class="col-lg-6 col-md-12">
                    <div class="categorie-search-box">
                        <form action="#">

                            <input type="text" name="search" class="medicine_search" autocomplete="off" placeholder="Search a product ... ">

                            <!-- SEARCH RESULTS -->

                            <div class="col-md-12 mx-auto td-auto-suggest-div d-none" style="border-radius: 7px;background-color: #ffffff;z-index: 1;padding: 15px;">

                                    <div class="text-center p-3 d-none no_record_found_div" id="">
                                        <p class="text-danger"> No record found </p>
                                    </div>
                                    <!-- Div Containing search items response -->
                                    <div class="d-none td_search_results_div" id=""></div>
                                </div>

                            <!-- ./ SEARCH RESULTS -->


                        </form>
                    </div>
                </div>
                <!-- Categorie Search Box End Here -->
                <!-- Cart Box Start Here -->
                <div class="col-lg-3 col-md-12">
                    <div class="cart-box mt-all-30">
                        <ul class="d-flex justify-content-lg-end justify-content-center align-items-center">
                          
                            <li id="cart-header-nav"></li>
                        </ul>
                    </div>
                </div>
                <!-- Cart Box End Here -->
            </div>
            <!-- Row End -->
        </div>
        <!-- Container End -->
    </div>
    <!-- Header Middle End Here -->
    <!-- Header Bottom Start Here -->
    <div class="header-bottom dark-pink-bg header-bottom-two header-sticky">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-12 ">

                    <nav class="d-none d-lg-block topnavigation">
                        <ul class="header-bottom-list home-style-theree-menu d-flex">

                            <li><a href="<?php echo e(asset('/')); ?>">Home</a></li>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(count($category->subCategories)>0): ?>
                                <li><a href="<?php echo e(route('category', ['slug' => $category->seo_url_slug])); ?>"><?php echo e($category->title); ?><i class="fa fa-angle-down"></i></a>
                                    <!-- Home Version Dropdown Start -->
                                    <ul class="ht-dropdown dropdown-style-two">
                                        <?php $__currentLoopData = $category->subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><a href="<?php echo e(route('category', ['slug' => $subCategory->seo_url_slug])); ?>"><?php echo e($subCategory->title); ?></a></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                    <!-- Home Version Dropdown End -->
                                </li>
                                <?php else: ?>
                                    <?php if(empty($category->parent_id) || $category->parent_id == 0): ?>
                                        <li><a href="<?php echo e(route('category', ['slug' => $category->seo_url_slug])); ?>"><?php echo e($category->title); ?></a></li>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </ul>
                    </nav>
                    <div class="mobile-menu menu-style-two menu-style-three d-block d-lg-none" data-menu="Menu">
                        <nav>
                            <ul>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(count($category->subCategories)>0): ?>
                                        <li><a href="<?php echo e(''); ?>"><?php echo e($category->title); ?></a>
                                            <!-- Home Version Dropdown Start -->
                                            <ul >
                                                <?php $__currentLoopData = $category->subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><a href="<?php echo e(route('category', ['slug' => $category->seo_url_slug])); ?>"><?php echo e($subCategory->title); ?></a></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                            <!-- Home Version Dropdown End -->
                                        </li>
                                    <?php else: ?>
                                        <?php if(empty($category->parent_id) || $category->parent_id == 0): ?>
                                            <li><a href="<?php echo e(route('category', ['slug' => $category->seo_url_slug])); ?>"><?php echo e($category->title); ?></a></li>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
            <!-- Row End -->
        </div>
        <!-- Container End -->
    </div>
    <!-- Header Bottom End Here -->
    <!-- Mobile Vertical Menu Start Here -->
    <div class="container d-none">
        <div class="vertical-menu mt-30">
            <span class="categorie-title mobile-categorei-menu">all Categories <i class="fa fa-angle-down"></i></span>
            <nav>
                <div id="cate-mobile-toggle" class="category-menu sidebar-menu sidbar-style mobile-categorei-menu-list menu-hidden ">
                    <ul>
                        <li class="has-sub"><a href="#">Electronics</a>
                            <ul class="category-sub">
                                <li><a href="#shop.html">Cords and Cables</a></li>
                                <li><a href="#shop.html">gps accessories</a></li>
                                <li><a href="#shop.html">Microphones</a></li>
                                <li><a href="#shop.html">Wireless Transmitters</a></li>
                            </ul>
                            <!-- category submenu end-->
                        </li>
                        <li class="has-sub"><a href="#">Fashion</a>
                            <ul class="category-sub">
                                <li><a href="#shop.html">Fashion one</a></li>
                                <li><a href="#shop.html">Fashion two</a></li>
                                <li><a href="#shop.html">Fashion three</a></li>
                                <li><a href="#shop.html">Fashion Four</a></li>
                            </ul>
                            <!-- category submenu end-->
                        </li>
                        <li class="has-sub"><a href="#">Home & Kitchen</a>
                            <ul class="category-sub">
                                <li><a href="#shop.html">kithen one</a></li>
                                <li><a href="#shop.html">kithen two</a></li>
                                <li><a href="#shop.html">kithen three</a></li>
                                <li><a href="#shop.html">kithen four</a></li>
                            </ul>
                            <!-- category submenu end-->
                        </li>
                        <li class="has-sub"><a href="#">Phones & Tablets</a>
                            <ul class="category-sub">
                                <li><a href="#shop.html">phone one</a></li>
                                <li><a href="#shop.html">Tablet two</a></li>
                                <li><a href="#shop.html">Tablet three</a></li>
                                <li><a href="#shop.html">phone four</a></li>
                            </ul>
                            <!-- category submenu end-->
                        </li>
                        <li class="has-sub"><a href="#">TV & Video</a>
                            <ul class="category-sub">
                                <li><a href="#shop.html">smart tv</a></li>
                                <li><a href="#shop.html">real video</a></li>
                                <li><a href="#shop.html">Microphones</a></li>
                                <li><a href="#shop.html">Wireless Transmitters</a></li>
                            </ul>
                            <!-- category submenu end-->
                        </li>
                        <li><a href="#">Beauty</a> </li>
                        <li><a href="#">Sport & tourisim</a></li>
                        <li><a href="#">Meat & Seafood</a></li>
                    </ul>
                </div>
                <!-- category-menu-end -->
            </nav>
        </div>
    </div>
    <!-- Mobile Vertical Menu Start End -->
</header>

<?php /**PATH D:\xampp\htdocs\onlinepharmacyshop.co.uk\shop\resources\views/frontend/include/header.blade.php ENDPATH**/ ?>