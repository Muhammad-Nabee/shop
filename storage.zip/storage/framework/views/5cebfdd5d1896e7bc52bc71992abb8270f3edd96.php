<!-- Signup Newsletter Start -->
<div class="newsletter dark-pink-bg">
    <div class="container">
        <div class="row">
            <div class="col-xl-5 col-lg-6">
                <div class="main-news-desc mb-all-30">
                    <div class="news-desc">
                        <h3>Sign Up For Newsletters</h3>
                        <p>Be the First to Know. Sign up for newsletter today</p>
                    </div>
                </div>
            </div>
            <div class="col-xl-7 col-lg-6">
                <div class="newsletter-box">
                    <form action="#">
                        <input class="subscribe" placeholder="your email address" name="email" id="subscribe" type="text">
                        <button type="submit" class="submit">subscribe!</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Signup-Newsletter End -->
<!-- Footer Area Start Here -->
<footer class="white-bg pt-45">
    <!-- Footer Top Start -->
    <div class="footer-top">
        <div class="container">
            <div class="row">
                <!-- Single Footer Start -->
                <div class="col-xl-2 col-lg-2 col-md-4 col-sm-6">
                    <div class="single-footer mb-sm-40">
                        <h3 class="footer-title">Quick Links</h3>
                        <div class="footer-content">
                            <ul class="footer-list">
                                <?php $__currentLoopData = $pharmacy_menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($menu['position_id'] == 2): ?>
                                        <?php $__currentLoopData = $menu['pharmacy_menu_links']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $target = "";
                                                if($link['reference_type'] == "SERVICE"){
                                                    $alink = route('service_details_page', ['url_slug' => $link['service']['slug'] ]);
                                                }
                                                if($link['reference_type'] == "PAGE"){
                                                    $alink = route('page', ['slug' => $link['page']['url_slug'] ]);
                                                }
                                                if($link['reference_type'] == "STATIC_PAGE") {
                                                    $alink = "/".$link['static_page']['url'];
                                                }
                                                if($link['reference_type'] == "URL") {
                                                    $alink = $link['reference_url'];
                                                    if($link['new_tab'] == '1') {
                                                        $target = 'target=_blank';
                                                    }
                                                }
                                            ?>
                                            <li class="">
                                                <a href="<?php echo e($alink); ?>" <?php echo e($target); ?>> <?php echo e($link['title']); ?></a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- Single Footer Start -->
                <!-- Single Footer Start -->
                <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6">
                    <div class="single-footer style-change mb-sm-40">
                        <h3 class="footer-title">Popular Products</h3>
                        <div class="footer-content">
                            <ul class="footer-list">
                                <?php $__currentLoopData = $pharmacy_menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($menu['position_id'] == 3): ?>
                                        <?php $__currentLoopData = $menu['pharmacy_menu_links']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $target = "";
                                                if($link['reference_type'] == "SERVICE"){
                                                    $alink = route('service_details_page', ['url_slug' => $link['service']['slug'] ]);
                                                }
                                                if($link['reference_type'] == "PAGE"){
                                                    $alink = route('page', ['slug' => $link['page']['url_slug'] ]);
                                                }
                                                if($link['reference_type'] == "STATIC_PAGE") {
                                                    $alink = "/".$link['static_page']['url'];
                                                }
                                                if($link['reference_type'] == "URL") {
                                                    $alink = $link['reference_url'];
                                                    if($link['new_tab'] == '1') {
                                                        $target = 'target=_blank';
                                                    }
                                                }
                                            ?>
                                            <li class="">
                                                <a href="<?php echo e($alink); ?>" <?php echo e($target); ?>> <?php echo e($link['title']); ?></a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- Single Footer Start -->
                <!-- Single Footer Start -->
                <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6">
                    <div class="single-footer mb-sm-40">
                        <h3 class="footer-title">Customer Care</h3>
                        <div class="footer-content">
                            <ul class="footer-list">
                                <?php $__currentLoopData = $pharmacy_menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($menu['position_id'] == 5): ?>
                                        <?php $__currentLoopData = $menu['pharmacy_menu_links']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $target = "";
                                                if($link['reference_type'] == "SERVICE"){
                                                    $alink = route('service_details_page', ['url_slug' => $link['service']['slug'] ]);
                                                }
                                                if($link['reference_type'] == "PAGE"){
                                                    $alink = route('page', ['slug' => $link['page']['url_slug'] ]);
                                                }
                                                if($link['reference_type'] == "STATIC_PAGE") {
                                                    $alink = "/".$link['static_page']['url'];
                                                }
                                                if($link['reference_type'] == "URL") {
                                                    $alink = $link['reference_url'];
                                                    if($link['new_tab'] == '1') {
                                                        $target = 'target=_blank';
                                                    }
                                                }
                                            ?>
                                            <li class="">
                                                <a href="<?php echo e($alink); ?>" <?php echo e($target); ?>> <?php echo e($link['title']); ?></a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- Single Footer Start -->
                <!-- Single Footer Start -->
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6">
                    <div class="single-footer">
                        <div class="logo-footer">
                            <a href="<?php echo e(asset('/')); ?>"><img src="<?php echo e(url('storage/pharmacyprofile',$pharmacy_settings->logo_2)); ?>" alt="footer-logo" class="img-fluid"></a>
                        </div>
                        <div class="footer-content">

                            <h5 class="contact-info mtb-10">Find Us:</h5>
                            <p><?php echo e(addressWithComma($pharmacy_info)); ?></p>
                            <div class="social-footer-list mt-20">
                                <?php if(!empty($pharmacy_info->facebook_url)): ?>
                                    <a href="<?php echo e($pharmacy_info->facebook_url); ?>"><i class="fa fa-facebook"></i></a>
                                <?php endif; ?>
                                <?php if(!empty($pharmacy_info->instagram_url)): ?>
                                    <a href="<?php echo e($pharmacy_info->instagram_url); ?>"><i class="fa fa-instagram"></i></a>
                                <?php endif; ?>
                                <?php if(!empty($pharmacy_info->twitter_url)): ?>
                                    <a href="<?php echo e($pharmacy_info->twitter_url); ?>"><i class="fa fa-twitter"></i></a>
                                <?php endif; ?>
                                <?php if(!empty($pharmacy_info->linkedin_url)): ?>
                                    <a href="<?php echo e($pharmacy_info->linkedin_url); ?>"><i class="fa fa-linkedin"></i></a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Single Footer Start -->
            </div>
            <!-- Row End -->
        </div>
        <!-- Container End -->
    </div>
    <!-- Footer Top End -->
    <!-- Footer Middle Start -->
    <div class="footer-middle text-center pb-20">
        <div class="container">
            <div class="footer-middle-content ptb-45">
                <div class="tag-content">

                    <?php $__currentLoopData = $pharmacy_menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($menu['position_id'] == 4): ?>
                            <?php $__currentLoopData = $menu['pharmacy_menu_links']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $target = "";
                                    if($link['reference_type'] == "SERVICE"){
                                        $alink = route('service_details_page', ['url_slug' => $link['service']['slug'] ]);
                                    }
                                    if($link['reference_type'] == "PAGE"){
                                        $alink = route('page', ['slug' => $link['page']['url_slug'] ]);
                                    }
                                    if($link['reference_type'] == "STATIC_PAGE") {
                                        $alink = "/".$link['static_page']['url'];
                                    }
                                    if($link['reference_type'] == "URL") {
                                        $alink = $link['reference_url'];
                                        if($link['new_tab'] == '1') {
                                            $target = 'target=_blank';
                                        }
                                    }
                                ?>
                                    <a href="<?php echo e($alink); ?>" <?php echo e($target); ?>> <?php echo e($link['title']); ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
                <div class="payment mt-25">
                    <a href="#"><img class="img" src="<?php echo e(asset('assets/img/payment/1.png')); ?>" alt="payment-image"></a>
                </div>
            </div>
        </div>
        <!-- Container End -->
    </div>
    <!-- Footer Middle End -->
    <!-- Footer Bottom Start -->
    <div class="footer-bottom off-white-bg ptb-25">
        <div class="container">
            <div class="col-sm-12">
                <div class="row justify-content-md-between justify-content-center footer-bottom-content">
                    <p>Copyright © <a target="_blank" href="<?php echo e(asset('/')); ?>">Onlinepharmacyshop</a> All Rights Reserved.</p>
                    <div class="footer-bottom-nav mt-sm-15">
                        <p>Website  by <a href="https://pharmafocus.co.u">Pharmafocus.co.uk</a></p>
                    </div>
                </div>
                <!-- Row End -->
            </div>
        </div>
        <!-- Container End -->
    </div>
    <!-- Footer Bottom End -->
</footer>
<!-- Footer Area End Here -->



<?php /**PATH D:\xampp\htdocs\onlinepharmacyshop.co.uk\shop\resources\views/frontend/include/footer.blade.php ENDPATH**/ ?>