
<?php $__env->startSection('title' ,'Contact Us'); ?>
<?php $__env->startSection('style'); ?>
  <style type="text/css">
    .contact-area .form-control {
       background: #ffffff none repeat scroll 0 0 !important;
    }
  </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="breadcrumb-area mt-30">
        <div class="container">
            <div class="breadcrumb">
                <ul class="d-flex align-items-center">
                    <li><a href="<?php echo e(asset('/')); ?>">Home</a></li>
                    <li class="active"><a href="javascript:;">Contact Us</a></li>
                </ul>
            </div>
        </div>
        <!-- Container End -->
    </div>
    <!-- Breadcrumb End -->
    <!-- Google Map Start -->
    <div class="goole-map pt-40 d-none">
        <div class="container">
            <div id="map" style="height:400px"></div>
        </div>
    </div>
    <!-- Google Map End -->
    <!-- Contact Email Area Start -->
    <div class="contact-area ptb-45">
        <div class="container">

             <?php if(\Session::has('success')): ?>
                        <div class="alert alert-success" id="alert-success">
                            <p><?php echo e(\Session::get('success')); ?></p>
                        </div><br />
                    <?php endif; ?>
                    <?php if(\Session::has('error')): ?>
                        <div class="alert alert-danger" id="alert-danger">
                            <p><?php echo e(\Session::get('error')); ?></p>
                        </div><br />
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="alert alert-danger"><?php echo e($error); ?></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                    <?php if(\Session::has('failure')): ?>
                        <div class="alert alert-danger" id="alert-danger">
                            <p><?php echo e(\Session::get('failure')); ?></p>
                        </div><br />
                    <?php endif; ?>

            <h3 class="mb-20">Contact Us</h3>
            <p class="text-capitalize mb-20">Send us a message by filling this form</p>
            <div class="card">
                <div class="card-body">
                       <form id="process_contact" method="post" action="<?php echo e(url('/contact-us')); ?>" autocomplete="off">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>First Name <span> *</span></label>
                                        <input type="text" name="first_name" class="form-control"  required value="<?php echo e(old('first_name')); ?>">
                                    </div>
                                </div>
                                  <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Last Name<span> *</span></label>
                                        <input type="text" name="last_name" class="form-control"  required value="<?php echo e(old('last_name')); ?>">
                                    </div>
                                </div>
                                
                            </div>
                       
                            <!-- /row -->
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Email<span> *</span></label>
                                        <input type="email" name="email_address" class="form-control"  required value="<?php echo e(old('email_address')); ?>">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Telephone</label>
                                        <input type="text"  name="contact_no" class="form-control" value="<?php echo e(old('contact_no')); ?>">
                                    </div>
                                </div>
                            </div>
                            <!-- /row -->
                        <div class="row">
                            <div class="col-md-12"> 
                                <div class="form-group">
                                    <label>Message<span> *</span></label>
                                    <textarea id="form_message" name="message" class="form-control" placeholder="Your message" rows="3" required="required" data-error="Message is required."><?php echo e(old('message')); ?></textarea>
                                </div>
                            </div>
                        </div>
                      

                       

                       <div class="row">
                            <div class="col-md-12"> 
                               <div class="address-textarea">
                                    <?php echo $__env->make('frontend.components.re_captcha', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div>

                        
                        <div class="row">
                            <div class="col-md-12"> 
                                 <input value="Submit" class="return-customer-btn" id="contact_submit_btn" type="submit">
                            </div>
                        </div>  
                        
                            
                </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/bs-stepper/dist/js/bs-stepper.min.js"></script>

    <script src="<?php echo e(asset('assets/js/mc_scripts/form_validation/dist/jquery.validate.js')); ?>"></script>
    <script src="https://ajax.aspnetcdn.com/ajax/jquery.validate/1.15.0/additional-methods.js"></script>
    <script>
        $(document).ready(function(){

            $('#contact_submit_btn').click(function(){

                var validator = $('#process_contact').validate();
                if(validator.form() != false){
                    // error => false
                    $('#process_contact')[0].submit();
                } else {
                    // error => true
                } //

            }); // click => #submit_btn

        });

    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Frontend-onlinepharmacyshop\resources\views/frontend/contactus/index.blade.php ENDPATH**/ ?>