<table border="1" width="100%" cellpadding="5" style="border-collapse: collapse !important;">
    <tr>
        <th width="70%" align="left"><strong>Medicine Title </strong> </th>
        <th width="10%"><strong>Qty </strong> </th>
        <th width="20%" align="right"><strong>Price (&pound;) </strong> </th>
    </tr>

    <?php $grand_total = $order->price; ?>

    <?php $__currentLoopData = $order_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>
                <p>
                    <?php echo e($order_detail->product ? ucfirst(filter_string($order_detail->product->title)) : ''); ?>

                </p>
                <?php if(!empty($order_detail->offer_text)): ?>
                    <?php
                    $offer = json_decode($order_detail->offer_text, 1);
                    ?>
                    <?php if(!empty($offer) && is_array($offer)): ?>
                        <p>
                            <strong>Offer: </strong>
                            <small>
                                <?php echo e(@$offer["name"]); ?>

                                <?php if($offer["type"] === \App\Models\Offer::TYPE_PERCENT): ?> (<?php echo e(round($offer["off"], 1). '% off'); ?>) <?php endif; ?>
                                <?php if($offer["type"] === \App\Models\Offer::TYPE_PRICE): ?> (<?php echo e('£'.round($offer["off"], 1). ' off'); ?>) <?php endif; ?>
                            </small>
                        </p>
                    <?php endif; ?>
                <?php endif; ?>
            </td>
            <td align="center">
                <?php echo e(ucfirst(filter_string($order_detail->qty))); ?>

            </td>
            <td align="right">
              <?php echo e(ucfirst(filter_string($order_detail->qty))); ?> x <?php echo e(number_format($order_detail->active_price,2)); ?>

            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php if(!empty($order->delivery_method_title) && $order->delivery_method_title): ?>
        <?php
          $grand_total = $grand_total + $order->delivery_price_charged;
        ?>
        <tr>
            <td colspan="2" align="right">
                <strong><?php echo (!empty($order->delivery_method_title)) ? filter_string($order->delivery_method_title) : ''; ?></strong><br>
                <small><?php echo (!empty($order->delivery_method_short_desc)) ? filter_string($order->delivery_method_short_desc) : ''; ?></small>
            </td>
            <td align="right">
                &pound;<?php echo (!empty($order->delivery_method_title)) ? number_format(trim($order->delivery_price_charged), 2) : ''; ?>
            </td>
        </tr>
    <?php endif; ?>

     <?php if(!empty($order->coupon_code_id) && $order->coupon_code_id): ?>
       <?php
        $coupon_calculate = calculateCoupon($order,$grand_total);
        $grand_total = $grand_total - $coupon_calculate['coupon_discount_price'];
       ?>
        <tr>
            <td colspan="2" align="right">
                <strong> Coupon Code </strong>
            </td>

            <td align="right">
                  -&pound;<?php echo e(number_format($order->coupon_code_discount_amount, 2)); ?>

            <?php echo e($coupon_calculate['percentage']); ?>

            </td>
        </tr>

    <?php endif; ?>


    <tr>

        <td align="right" colspan="2"><strong>Total: </strong> </td>
        <td class="grey-bg" align="right">
             <strong> &pound;<?php echo number_format($grand_total, 2); ?> </strong>
        </td>

    </tr>

</table>

<?php /**PATH D:\xampp\htdocs\Frontend-onlinepharmacyshop\resources\views/frontend/emails/patient_order_completed.blade.php ENDPATH**/ ?>