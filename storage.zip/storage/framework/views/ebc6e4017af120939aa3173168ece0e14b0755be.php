
<li class="dropdown cart_dropdown"><a class="nav-link cart_trigger" href="#" data-bs-toggle="dropdown"><i class="linearicons-cart"></i><span class="cart_count">
<?php if(count($cart['items'])<1): ?>
0
<?php else: ?>
<?php echo e(count($cart['items'])); ?>

<?php endif; ?>
</span>
</a>
<div class="cart_box dropdown-menu dropdown-menu-right">
    <?php if(count($cart['items'])<1): ?>
         <ul class="cart_list">
            <li>No Item</li>
        </ul>
    <?php else: ?>
    <ul class="cart_list">
        <?php $__currentLoopData = $cart['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $each): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
              $product = $each['item'];
            ?>
            <li>
                <a href="javascript:;" class="item_remove remove-item-from-cart" data-id="<?php echo e($product['id']); ?>"><i class="ion-close"></i></a>
                <a href="#">
                <?php $__currentLoopData = $product['media']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($loop->first): ?>
                        <img src="<?php echo e(asset('storage/products/'.$media['media'])); ?>" alt="<?php echo e($product['title']); ?>">
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($product['title']); ?></a>
                <span class="cart_quantity"> <?php echo e($each['qty'].'X'); ?><span class="cart_amount"> <span class="price_symbole">AED</span></span><?php echo e(number_format($each['discount_price'], 2)); ?></span>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <div class="cart_footer">
        <p class="cart_total"><strong>Subtotal:</strong> <span class="cart_price"> <span class="price_symbole">AED</span></span><?php echo e(number_format(cartPrice(), 2)); ?></p>
        <p class="cart_buttons"><a href="<?php echo e(url('cart/view')); ?>" class="btn btn-fill-line btn-radius view-cart">View Cart</a><a href="#" class="btn btn-fill-out btn-radius checkout">Checkout</a></p>
    </div>
    <?php endif; ?>
</div>
</li>
<?php /**PATH D:\xampp\htdocs\tdprojects\shop\resources\views/frontend/components/cartListNew.blade.php ENDPATH**/ ?>