<!-- Google Captcha V2 Script -->
<script src="https://www.google.com/recaptcha/api.js" async defer></script>
<!-- Google Captcha V2 Div -->
<div class="g-recaptcha"
     data-sitekey="<?php echo getRecaptacha(); ?>">
</div>
<?php /**PATH D:\xampp\htdocs\Frontend-onlinepharmacyshop\resources\views/frontend/components/re_captcha.blade.php ENDPATH**/ ?>