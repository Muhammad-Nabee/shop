
<?php $__env->startSection('title', 'Login'); ?>
<?php $__env->startSection('style'); ?>
    <style type="text/css">
        .red{
          color:red;
        }
        .has-error{
          color: #f00 !important;
        }
        .error {
           color: #f00 !important;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="log-in ptb-45">
        <div class="container">
            <div class="row">
                <!-- Returning Customer Start -->
                <div class="col-md-6 mx-auto">
                    <?php echo $__env->make('frontend.include.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="well">
                        <div class="return-customer">
                            <h3 class="mb-10 custom-title">Log in</h3>
                             <p class="mb-10">
                                <strong>I am a returning customer</strong>
                             </p>
                             <form  action="<?php echo e(url('/login')); ?>" class="prevent_enter_key" id="login_form" method="post" accept-charset="utf-8">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Email</label>
                                            <input type="text" name="email" placeholder="" id="email" required class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Password</label>
                                            <input type="password" name="password" placeholder="" id="password" required class="form-control">
                                        </div>
                                        <p class="lost-password text-right"><a href="<?php echo e(url('forgot-password')); ?>">Forgot password?</a></p>
                                    </div>

                                       <?php

                                          $recaptcha_attempt  = globalSettings('recaptcha_attempt');

                                          $recaptcha_attempt = $recaptcha_attempt != null ? $recaptcha_attempt : Config::get('constants.keys.recaptcha_attempt');

                                        ?>

                                        <?php if(attemptCount() > $recaptcha_attempt): ?>
                                        <div class="col-md-12">
                                                <div class="form-group">
                                                <div class="form-group">
                                                    <?php echo $__env->make("frontend.components.re_captcha", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                </div>
                                            </div>
                                        </div>

                                        <?php endif; ?>

                                    <div class="col-md-12">

                                        <input type="submit" value="Login" id="login_submit" class="btn-colour-blue">
                                    </div>
                                    <div class="col-md-12 mt-3">

                                        <p>Don't have an account yet? <a href="<?php echo e(url('register')); ?>">Register Now</a></p>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- Returning Customer End -->
            </div>
            <!-- Row End -->
        </div>
        <!-- Container End -->
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/bs-stepper/dist/js/bs-stepper.min.js"></script>
    <script src="<?php echo e(asset('assets/js/mc_scripts/form_validation/dist/jquery.validate.js')); ?>"></script>
    <script src="https://ajax.aspnetcdn.com/ajax/jquery.validate/1.15.0/additional-methods.js"></script>
    <script>
        $(document).ready(function(){
            $('#login_submit').click(function(){
                var validator = $('#login_form').validate();
                if(validator.form() != false){
                    // error => false
                    $('#login_form')[0].submit();
                } else {
                    // error => true
                } //
            }); // click => #submit_bt
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Frontend-onlinepharmacyshop\resources\views/frontend/patient/login.blade.php ENDPATH**/ ?>