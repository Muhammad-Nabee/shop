<!-- START HEADER -->
<header class="header_wrap fixed-top header_with_topbar">
  <div class="top-header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                  <div class="d-flex align-items-center justify-content-center justify-content-md-start">
                        <?php if(!empty($pharmacy_info->contact_number_p)): ?>
                            <ul class="contact_detail text-center text-lg-start">
                                <li><i class="ti-mobile"></i><span><?php echo e($pharmacy_info->contact_number_p); ?></span></li>
                            </ul>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-md-6">
                  <div class="text-center text-md-end">
                        <ul class="header_list">
                          
                            <li><a href="login.html"><i class="ti-user"></i><span>Login</span></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="bottom_header dark_skin main_menu_uppercase">
      <div class="container">
            <nav class="navbar navbar-expand-lg"> 
                <a class="navbar-brand" href="index.html">
                    <img class="logo_light" src="<?php echo e(asset('new/assets/images/logo_light.png')); ?>" alt="logo" />
                    <img class="logo_dark" src="<?php echo e(asset('new/assets/images/logo_dark.png')); ?>" alt="logo" />
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-expanded="false"> 
                    <span class="ion-android-menu"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-center" id="navbarSupportedContent">
                    <ul class="navbar-nav">
                     
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('/home1')); ?>">Home</a>
                    </li>
                      <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('products')); ?>"> Products </a>
                    </li>
                    <?php $__currentLoopData = $pharmacy_menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($menu['position_id'] == 1): ?>
                        <?php $__currentLoopData = $menu['pharmacy_menu_links']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php
                                $target = "";
                                if($link['reference_type'] == "SERVICE"){

                                  $alink = !empty($link['service']['service_url']) ? @$link['service']['service_url'] : url('/services', @$link['service']['slug']);


                                }

                                if($link['reference_type'] == "PAGE"){
                                    $alink = route('page', ['slug' => @$link['page']['url_slug'] ]);
                                }

                                if($link['reference_type'] == "STATIC_PAGE") {
                                    $alink = "/".@$link['static_page']['url'];
                                }

                                if($link['reference_type'] == "URL") {
                                    $alink = @$link['reference_url'];
                                    if($link['new_tab'] == '1') {
                                        $target =  'target=_blank';
                                    }
                                }

                            ?>


                            <?php if(count($link['childs']) > 0 ): ?>

                                <li class="dropdown">

                                    <a href="<?php echo e(@$alink); ?>" <?php echo e($target); ?> class="nav-link dropdown-toggle" ><?php echo e(@$link['title']); ?></a>
                                    <ul class="dropdown-menu" role="menu">
                                        <?php $__currentLoopData = $link['childs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child_link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php

                                                $target = "";
                                                if($child_link['reference_type'] == "SERVICE"){

                                                       $child_sub_link = !empty($child_link['service']['service_url']) ? $child_link['service']['service_url'] : url('/services', $child_link['service']['slug']);

                                                  }
                                                  if($child_link['reference_type'] == "PAGE"){

                                                      $child_sub_link = route('page', ['url_slug' => $child_link['page']['url_slug'] ]);

                                                  }

                                                  if($child_link['reference_type'] == "STATIC_PAGE"){

                                                      $child_sub_link = "/".$child_link['static_page']['url'];

                                                  }

                                                  if($child_link['reference_type'] == "URL"){

                                                      $child_sub_link = $child_link['reference_url'];

                                                      if($link['new_tab'] == 'Y'){

                                                          $target = 'target=_blank';
                                                      }

                                                  }

                                            ?>
                                            <li class="nav-item">
                                                <a class="dropdown-item" href="<?php echo e($child_sub_link); ?>" <?php echo e($target); ?>> <?php echo e($child_link['title']); ?></a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </ul>
                                </li>
                            <?php else: ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e($alink); ?>" <?php echo e($target); ?>> <?php echo e($link['title']); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </ul>
                </div>
                <ul class="navbar-nav attr-nav align-items-center">
                    <li><a href="javascript:void(0);" class="nav-link search_trigger"><i class="linearicons-magnifier"></i></a>
                        <div class="search_wrap">
                            <span class="close-search"><i class="ion-ios-close-empty"></i></span>
                            <form>
                                <input type="text" placeholder="Search" class="form-control" id="search_input">
                                <button type="submit" class="search_icon"><i class="ion-ios-search-strong"></i></button>
                            </form>
                        </div><div class="search_overlay"></div><div class="search_overlay"></div>
                    </li>
                <div id="cart-header-nav"></div>
            </ul>
            </nav>
        </div>
    </div>
</header>
<!-- END HEADER -->
<?php /**PATH D:\xampp\htdocs\tdprojects\shop\resources\views/frontend/include/header.blade.php ENDPATH**/ ?>