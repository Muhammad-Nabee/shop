
<?php $__env->startSection('title', 'Orders'); ?>
<?php $__env->startSection('style'); ?>
<style type="text/css">
     .red{
        color:red;
     }
 </style>

 <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap4.min.css">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('patient-content'); ?>

 <div class="col-md-12">
    <h3 class="mb-10 custom-title mb-4"> Orders </h3>
    <!-- Returning Customer Start -->
     <div class="table-responsive">
         <table id="orders-datatable" class="table w-100 table-condensed table-striped">
             <thead class="dark-pink-bg text-white">
             <tr>
                 <th class="d-none">sr#</th>
                 <th>Order ID</th>
                 <th>Order Date</th>
                 <th>Order Status</th>
                 <th>Price</th>
                 <th>Details</th>
             </tr>

             </thead>
             <tbody>
             <?php if(count($orders) > 0): ?>
                 <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                     <?php
                     $savedCart = [];
                     if(!empty($order->txn_cart)) {
                         $savedCart = json_decode($order->txn_cart, 1);
                     }
                     $grand_total = ($savedCart["discountPrice"] - $savedCart["couponFree"]) + $savedCart["deliveryFee"];
                     ?>

                     <tr>
                         <td class="d-none"><?php echo e($loop->index); ?></td>
                         <td>
                             <?php echo e($order->invoice_no); ?>

                         </td>
                         <td>
                             <?php echo e($order->created_at->format('d/m/Y')); ?>

                         </td>
                         <td>
                             <?php if($order->status === 'P'): ?>
                                 <span class="font-weight-bold">Pending</span>
                             <?php elseif($order->status === 'D'): ?>
                                 <span class="font-weight-bold">Declined</span>
                                 <br>
                                 <?php if(!empty($order->accept_note)): ?>
                                    <small class="order-note"  data-note="<?php echo e($order->accept_note); ?>" style="cursor:pointer;"> Order Note </small>
                                 <?php endif; ?>

                             <?php elseif($order->status === 'C'): ?>
                                 <span class="font-weight-bold">Completed</span>
                                 <br>
                                 <?php if(!empty($order->accept_note)): ?>
                                    <small class="order-note" style="cursor:pointer;" data-note="<?php echo e($order->accept_note); ?>"> Order Note </small>
                                 <?php endif; ?>
                             <?php elseif($order->status === 'DISPENSED'): ?>
                                 <span class="font-weight-bold">DISPENSED</span>
                             <?php endif; ?>
                        
                         </td>
                         <td>
                             £<?php echo e(number_format($grand_total,2)); ?>

                         </td>
                         <td>
                             <a href="<?php echo e(url('patient-order-details',$order->hash_id)); ?>" >
                                 <button class="btn-colour-blue"> View Details </button>
                             </a>
                         </td>
                     </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <?php else: ?>
                 <tr>
                     <td colspan="5" class="text-center">
                         No data found
                     </td>
                 </tr>
             <?php endif; ?>
             </tbody>
         </table>    <!-- Returning Customer End -->
     </div>

     <div class="modal" id="select-order-note" style="z-index: 9999">
        <div class="modal-dialog">
            <div class="modal-content">
                <!-- Modal Heade-->
                <div class="modal-header">
                    <h4 class="modal-title mt-0">
                        Order Note
                    </h4>
                    <button type="button" class="close close-mod" data-dismiss="modal">&times;</button>
                </div>
                <!-- Modal body -->
                <div class="modal-body">
                    <div id="order-note-p">
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
        $(document).ready(function() {
           $('#orders-datatable').DataTable( {

           });


            $('.close-mod').click(function (){
                $('#select-order-note').hide();
            });

        });

        $(document).on("click", ".order-note", function(){
                var note = $(this).data('note');
                $('#order-note-p').html('<p>'+note+'</p>');    
                $('#select-order-note').show();
        });



    </script>
    <script type="text/javascript" language="javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.11.3/js/dataTables.bootstrap4.min.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.patient.dashboard_new', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Frontend-onlinepharmacyshop\resources\views/frontend/patient/orders.blade.php ENDPATH**/ ?>