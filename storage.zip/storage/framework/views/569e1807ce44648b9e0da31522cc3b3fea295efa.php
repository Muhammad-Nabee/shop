

<?php $__env->startSection('title', !empty($category->meta_title) ? ucwords($category->meta_title) : ucwords($category->title)); ?>
<?php $__env->startSection('description',!empty($category->meta_description) ? $category->meta_description : $category->title); ?>
<?php $__env->startSection('keywords',!empty($category->meta_keywords) ? $category->meta_keywords : $category->title); ?>

<?php $__env->startSection('content'); ?>

    <!-- Breadcrumb Start -->
    <div class="breadcrumb-area mt-40">
        <div class="container">
            <div class="breadcrumb">
                <ul class="d-flex align-items-center">
                    <li><a href="<?php echo e(asset('/')); ?>">Home</a></li>
                    <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $breadcrumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <li 
                       <?php if(count($breadcrumbs) == ++$key): ?> class="active" <?php endif; ?>
                       >
                       <a href="<?php echo e($breadcrumb->seo_url_slug); ?>"><?php echo e($breadcrumb->title); ?></a>
                       </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
        <!-- Container End -->
    </div>
    <!-- Breadcrumb End -->
    <!-- Shop Page Start -->
    <div class="main-shop-page ptb-45">
        <div class="container">
            <!-- Row End -->
            <div class="row">
                <!-- Sidebar Shopping Option Start -->
                <div class="col-lg-3 order-2 order-lg-1">
                    <div class="sidebar">
                        <!-- Sidebar categorieslist  Start -->
                        <div class="categorieslist mb-30">
                            <h3 class="sidebar-title e-title mt-0"><?php echo e($category->title); ?></h3>
                            
                            <?php if(count($category->subCategories) > 0 ): ?>
                                <div id="shop-cate-toggle" class="category-menu sidebar-menu sidbar-style">
                                    <ul class="categoriesul">
                                        
                                        <?php $__currentLoopData = $category->subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categ): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php 
                                               $product_count = CommonHelper::productCount($categ);
                                            ?>
                                            <?php if($product_count > 0): ?>
                                                <li class=""><a href="<?php echo e(route('category', ['slug' => $categ->seo_url_slug])); ?>"><?php echo e($categ->title); ?> (<?php echo e($product_count); ?>) </a></li>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>

                          <!-- category-menu-end -->
                        </div>
                        <!-- Sidebar categorieslist  End -->
                    </div>
                </div>
                <!-- Sidebar Shopping Option End -->
                <!-- Product Categorie List Start -->
                <div class="col-lg-9 order-1 order-lg-2">
                    <!-- Grid & List View Start -->
                    <div class="grid-list-top border-default universal-padding d-md-flex justify-content-md-between align-items-center mb-30">
                        <div class="grid-list-view  mb-sm-15">
                            <ul class="nav tabs-area d-flex align-items-center">
                                <li><a data-toggle="tab" href="#grid-view"><i class="fa fa-th"></i></a></li>
                                <li><a class="active" data-toggle="tab" href="#list-view"><i class="fa fa-list-ul"></i></a></li>
                                <li><span class="grid-item-list"><?php echo e(count($products)); ?> Product(s).</span></li>
                            </ul>
                        </div>
                        <!-- Toolbar Short Area Start -->
                        <div class="main-toolbar-sorter clearfix">
                            <div class="toolbar-sorter d-md-flex align-items-center">
                                <label>Sort By:</label>
                                <select class="sorter wide form-control" id="product-sorting">
                                    <option value="">Relevance</option>
                                    <option value="<?php echo e(asset('chemist/'.$category->seo_url_slug.'?sortTitle=ASC')); ?>" <?php if($sort_title == 'ASC'): ?> selected <?php endif; ?>>Name, A to Z</option>
                                    <option value="<?php echo e(asset('chemist/'.$category->seo_url_slug.'?sortTitle=DESC')); ?>" <?php if($sort_title == 'DESC'): ?> selected <?php endif; ?>>Name, Z to A</option>
                                    <option value="<?php echo e(asset('chemist/'.$category->seo_url_slug.'?sortPrice=low')); ?>" <?php if($sort_price == 'low'): ?> selected <?php endif; ?>>Price low to high</option>
                                    <option value="<?php echo e(asset('chemist/'.$category->seo_url_slug.'?sortPrice=high')); ?>" <?php if($sort_price == 'high'): ?> selected <?php endif; ?>>Price high to low</option>
                                </select>
                            </div>
                        </div>
                        <!-- Toolbar Short Area End -->
                    </div>
                    <!-- Grid & List View End -->
<div class="main-categorie mb-all-40">
    <!-- Grid & List Main Area End -->
    <div class="tab-content border-default fix">
        <div id="grid-view" class="tab-pane fade ">
            <div class="row">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!-- Single Product Start -->
                <div class="col-lg-4 col-md-4 col-sm-6 col-6">
                    <div class="single-product">
                        <!-- Product Image Start -->
                        <div class="pro-img">
                            <a href="<?php echo e($product->seo_url_slug); ?>">
                                <?php $__currentLoopData = $product->media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($loop->first): ?>
                                        <img class="primary-img" src="<?php echo e(asset('storage/products/'.$media->media)); ?>" alt="<?php echo e($product->title); ?>">
                                    <?php endif; ?>

                                    <?php if($loop->index == 1): ?>
                                        <img class="secondary-img" src="<?php echo e(asset('storage/products/'.$media->media)); ?>" alt="<?php echo e($product->title); ?>" />
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </a>
                            <span class="sticker-new">new</span>
                        </div>
                        <!-- Product Image End -->
                        <!-- Product Content Start -->
                        <div class="pro-content">
                            <div class="pro-info">
                                <h4><a href="<?php echo e($product->seo_url_slug); ?>"><?php echo e($product->title); ?></a></h4>
                                <div class="product-rating">
                                <?php
                                    $review_avg = reviewCalculate($product); 
                                ?> 
                                <?php for($i = 1; $i <= 5; $i++): ?>
                                    <i class="fa fa-star fa-lg <?php echo e(($i <= $review_avg) ? 'star_active' : 'star_in_active'); ?>"></i>
                                <?php endfor; ?>
                                </div>
                                <p>
                                    <span class="price"><?php echo e($product->discount_price); ?>

                                    </span>
                                    <?php if($product->price != $product->discount_price): ?>    
                                        <del class="prev-price">£<?php echo e($product->price); ?></del>
                                    <?php endif; ?>
                                </p>
                            </div>
                            <div class="pro-actions">
                                <?php if($product->stock_level < 1): ?>
                                    <p>
                                        <span class="in-stock">
                                            <span class="text-danger">Out of Stock</span>
                                        </span>
                                    </p>
                                <?php else: ?>
                                    <div class="actions-primary">
                                        <a href="javascript:;" title="<?php echo e($product->title); ?>" data-id="<?php echo e($product->id); ?>" class="add-item-to-cart" data-original-title="Add to Cart">Add To Cart</a>
                                    </div>
                                <?php endif; ?>
                                <div class="actions-secondary">

                                    <a href="<?php echo e($product->seo_url_slug); ?>" title="" data-original-title="Details"><i class="fa fa-signal"></i></a>
                                </div>
                            </div>
                        </div>
                        <!-- Product Content End -->
                    </div>
                </div>
                <!-- Single Product End -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <!-- Row End -->
        </div>
        <!-- #grid view End -->
        <div id="list-view" class="tab-pane fade show active">
            <!-- Single Product Start -->
            <?php if(count($products)<1): ?>
                <p>No Items Found</p>
            <?php endif; ?>

            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row single-product">

                <!-- Product Image Start -->
                <div class="col-xl-3 col-lg-4 col-md-4 col-sm-5 col-4">
                    <div class="pro-img">
                        <a href="<?php echo e($product->seo_url_slug); ?>">
                            <?php $__currentLoopData = $product->media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($loop->first): ?>
                                    <img class="primary-img" src="<?php echo e(asset('storage/products/'.$media->media)); ?>" alt="<?php echo e($product->title); ?>">
                                <?php endif; ?>

                                <?php if($loop->index == 1): ?>
                                    <img class="secondary-img" src="<?php echo e(asset('storage/products/'.$media->media)); ?>" alt="<?php echo e($product->title); ?>" />
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </a>

                    </div>
                </div>
                <!-- Product Image End -->
                <!-- Product Content Start -->
                <div class="col-xl-9 col-lg-8 col-md-8 col-sm-7 col-8">
                    <div class="pro-content">
                        <h4><a href="<?php echo e($product->seo_url_slug); ?>"><?php echo e($product->title); ?></a></h4>
                        <div class="product-rating">
                              <?php
                                
                                $review_avg = reviewCalculate($product); ?> 
                                <?php for($i = 1; $i <= 5; $i++): ?>
                                    <i class="fa fa-star fa-lg <?php echo e(($i <= $review_avg) ? 'star_active' : 'star_in_active'); ?>"></i>
                                <?php endfor; ?>
                                
                        </div>
                        <p><span class="price">£<?php echo e($product->discount_price); ?></span>
                            <?php if($product->price != $product->discount_price): ?> <del class="prev-price">£<?php echo e($product->price); ?></del>
                            <?php endif; ?>

                        </p>
                        <p><?php echo $product->description; ?></p>
                        <div class="pro-actions">
                              <?php if($product->stock_level < 1): ?>
                                <p>
                                    <span class="in-stock">
                                        <span class="text-danger">Out of Stock</span>
                                    </span>
                                </p>
                            <?php else: ?>
                                <div class="actions-primary">
                                    <a href="javascript:;" data-id="<?php echo e($product->id); ?>" class="add-item-to-cart" title="Add to Cart">Add To Cart</a>
                                </div>
                            <?php endif; ?>
                            <div class="actions-secondary">

                                <a href="<?php echo e($product->seo_url_slug); ?>" title="Details"><i class="fa fa-signal"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Product Content End -->
            </div>
            <!-- Single Product End -->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <!-- #list view End -->
        <!-- Product Pagination Info -->
        <?php echo $products->links(); ?>

        <!-- End of .blog-pagination -->
    </div>
    <!-- Grid & List Main Area End -->
</div>
                </div>
                <!-- product Categorie List End -->
            </div>
            <!-- Row End -->
        </div>
        <!-- Container End -->
    </div>
    <!-- Shop Page End -->



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).on('change', '#product-sorting', function () {
            let url = $(this).val();
            if (url != '')
                location.replace(url);
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Frontend-onlinepharmacyshop\resources\views/frontend/category/show.blade.php ENDPATH**/ ?>