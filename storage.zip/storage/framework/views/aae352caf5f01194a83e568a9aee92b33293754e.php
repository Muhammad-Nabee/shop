
<?php $__env->startSection('title', 'Orders'); ?>
<?php $__env->startSection('style'); ?>
<style type="text/css">
     .red{
        color:red;
     }
     /*img-fluid {
        max-width: 100% !impo;
        height: auto;
    }*/
 </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('patient-content'); ?>
    <?php
        $savedCart = [];
        if(!empty($order->txn_cart)) {
            $savedCart = json_decode($order->txn_cart, 1);
        }
     ?>
<div class="col-md-12">
    <h3 class="mb-10 custom-title mb-4"> Orders Details</h3>
    <div class="row">
        <div class="col-md-4">
            <p class="mb-0">Order date:</p>
            <p class="font-weight-bold"><?php echo e($order->created_at->format('d/m/Y')); ?></p>
        </div>
        <div class="col-md-3">
            <p class="mb-0">Order Status:</p>
            <?php if($order->status === 'P'): ?>
                <p class="font-weight-bold">Pending</p>
            <?php elseif($order->status === 'D'): ?>
                <p class="font-weight-bold">Declined</p>
            <?php elseif($order->status === 'C'): ?>
                <p class="font-weight-bold">Completed</p>
            <?php elseif($order->status === 'DISPENSED'): ?>
                <p class="font-weight-bold">DISPENSED</p>
            <?php endif; ?>
        </div>
        <div class="col-md-2">
            <p class="mb-0">Order ID:</p>
            <p class="font-weight-bold"><?php echo e($order->invoice_no); ?></p>
        </div>
        <?php $trackingUrl = globalSettings("order_tracking_url"); ?>
        <?php if($order->tracking_code != null && !empty($trackingUrl)): ?>
            <div class="col-md-3">
                <p class="mb-0">Tracking Code:</p>
                <p class="font-weight-bold">
                    <?php $url = str_replace("[TRACKING_ID]", $order->tracking_code, $trackingUrl); ?>
                    <a href="<?php echo e($url); ?>" target="_blank">Track Order</a>

                </p>
            </div>
        <?php endif; ?>
    </div>
    <!-- medication list-->
    <div class="row mt-5">
        <div class="col-md-12">
            <div class="table-responsive">
                <table class="table card-table table-bordered table-vcenter text-nowrap mb-0">
                    <thead class="dark-pink-bg text-white">
                    <tr>
                        <th class="text-white">Image</th>
                        <th class="text-white">Product Title</th>
                        <th class="text-white" width="5%">Status</th>
                        <th class="text-white" width="10%">QTY</th>
                        <th class="text-white" width="15%">Price (£)</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $grand_total = $order->price; ?>
                    <?php $__currentLoopData = $order->orderDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $product = $order_details->product; ?>
                        <?php if(!empty($product)): ?>
                            <tr>
                                <td align="center">

                                    <?php if($order_details->product && $order_details->product->media && count($order_details->product->media) > 0): ?>
                                        <img
                                            src="<?php echo e(url('storage/products/'.$order_details->product->media[0]->media)); ?>"
                                            width="80px"
                                            class="img-responsive"/>
                                    <?php endif; ?>
                                    <br>
                                    <?php if($order->status === 'C' && $order_details->is_reviewed == null || $order_details->is_reviewed == '0'): ?>
                                        <a href="javascript:;"
                                           data-hash-id="<?php echo e($order_details->hash_id); ?>"
                                           class="btn btn-default btn-sm custom-a-link add-edit-review">
                                            Review this product
                                        </a>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <p class="mb-1">
                                        <?php echo e($order_details->product ? $order_details->product->title : ''); ?><br>
                                    </p>
                                    <?php if(!empty($order_details->offer_text)): ?>
                                        <?php
                                        $offer = json_decode($order_details->offer_text, 1);
                                        ?>
                                        <?php if(!empty($offer) && is_array($offer)): ?>
                                            <p class="mb-0">
                                                <strong class="text-success">Offer: </strong>
                                                <small class="text-success">
                                                    <?php echo e(@$offer["name"]); ?>

                                                    <?php if($offer["type"] === \App\Models\Offer::TYPE_PERCENT): ?> (<?php echo e(round($offer["off"], 1). '% off'); ?>) <?php endif; ?>
                                                    <?php if($offer["type"] === \App\Models\Offer::TYPE_PRICE): ?> (<?php echo e('£'.round($offer["off"], 1). ' off'); ?>) <?php endif; ?>
                                                </small>
                                            </p>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($order_details->status == 'P'): ?>
                                        <span class="font-weight-bold">Pending</span>
                                    <?php elseif($order_details->status == 'DISPENSED'): ?>
                                         <span class="font-weight-bold">Dispensed</span>
                                    <?php elseif($order_details->status == 'C'): ?>
                                         <span class="font-weight-bold">Completed</span>
                                        <?php if(!empty($order_details->approved_declined_note)): ?>
                                           <small class="order-note" style="cursor:pointer;" data-note="<?php echo e($order_details->approved_declined_note); ?>"> Order Note </small>
                                        <?php endif; ?>
                                    <?php else: ?>
                                         <span class="font-weight-bold">Declined</span>
                                        <?php if(!empty($order_details->approved_declined_note)): ?>
                                           <small class="order-note" style="cursor:pointer;" data-note="<?php echo e($order_details->approved_declined_note); ?>"> Order Note </small>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php echo e($order_details->qty); ?>

                                </td>
                                <td><?php echo e(number_format($order_details->price_charged,2)); ?></td>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if(!empty($order) && $order->delivery_method_id): ?>
                        <?php
                        $grand_total = $grand_total + $order->delivery_price_charged;
                        ?>
                        <tr>
                            <td colspan="3" align="right">
                                <strong> <?php echo e(($order->delivery_method_title) ? $order->delivery_method_title : ''); ?>  <br> <small> <?php echo e(($order->delivery_method_short_desc) ? $order->delivery_method_short_desc : ''); ?>. </small>
                                </strong> </td>
                            <td colspan="2" align="left">
                                &pound;<?php echo e(number_format($order->delivery_price_charged, 2)); ?>

                            </td>
                        </tr>
                    <?php endif; ?>
                    <?php if(!empty($order) && !empty($order->coupon_code_id)): ?>
                        <?php
                        $grand_total = ($savedCart["discountPrice"] - $savedCart["couponFree"]) + $savedCart["deliveryFee"];
                        ?>
                        <tr>
                            <td colspan="3" align="right"> <strong> Coupon Code </strong> </td>
                            <td colspan="2" align="left"> -&pound;<?php echo e(number_format($savedCart["couponFree"], 2)); ?> <?php echo e($order->coupon_type === "FIXED_PRICE" ? "" : "(".$order->coupon_type_percent_value."%)"); ?></td>
                        </tr>
                    <?php endif; ?>
                    <tr>
                        <td colspan="3" align="right" class="bg-light"><strong> Grand Total </strong></td>
                        <td colspan="2" align="left" class="bg-light"> <h4 class="p-0"> &pound;<?php echo e(number_format($grand_total, 2)); ?> </h4> </td>
                    </tr>
                    <tr>
                        <td colspan="5">
                            <p><strong> DELIVER TO </strong></p>
                            <?php if($order->patientOrderAddress): ?>
                                <p>
                                    <?php echo deliveryAddress($order); ?></p>
                            <?php endif; ?>
                        </td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="modal" id="select-order-note" style="z-index: 9999">
        <div class="modal-dialog">
            <div class="modal-content">
                <!-- Modal Heade-->
                <div class="modal-header">
                    <h4 class="modal-title mt-0">
                        Order Note
                    </h4>
                    <button type="button" class="close close-mod" data-dismiss="modal">&times;</button>
                </div>
                <!-- Modal body -->
                <div class="modal-body">
                    <div id="order-note-p">
                    </div>
                </div>
            </div>
        </div>
    </div>
 </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">

    $(document).on("click", ".order-note", function(){
            var note = $(this).data('note');
            $('#order-note-p').html('<p>'+note+'</p>');    
            $('#select-order-note').show();
    });

    $(document).ready(function () {

         $('.close-mod').click(function (){
            $('#select-order-note').hide();
        });

        $('.add-edit-review').click(function () {
        var hash_id = $(this).attr('data-hash-id');
        $.ajax({
                type: "GET",
                url: '<?php echo e(url('get-review-form')); ?>' + '/' + hash_id,
                // processData: false,
                // contentType: false,
                headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                beforeSend: function (result) {
                    // $("#loading").css("display","block");
                    $('#crud_errors_div').addClass('d-none');
                    $('#crud_errors_ul').html('');
                },
                success: function (response) {
                // $("#loading").css("display","none");
                // swal(response);
                var popup_title = '';
                if (hash_id == '') {
                  popup_title = 'Leave a Review';
                } else {
                  popup_title = 'Leave a Review';
                } // if(hash_id == '')
                    $('#mc-popup-dialog').addClass('modal-lg');
                    // Set Heading
                    $('#general_bootstrap_ajax_popup_heading').html(popup_title);
                    // Set Body
                    $('#crud_contents').html(response);
                    // Set Footer
                    // $('#general_bootstrap_ajax_popup_footer').prepend('');
                    $('#general_bootstrap_ajax_popup').modal({
                    backdrop: 'static',
                    keyboard: false
                    });
                    $('#general_bootstrap_ajax_popup').modal('show');
                }, // success
                error: function (xhr, status, error) {
                  mcShowErrorsGet(xhr, status, error);
                }
           }); // $.ajax
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.patient.dashboard_new', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Frontend-onlinepharmacyshop\resources\views/frontend/patient/order_details.blade.php ENDPATH**/ ?>