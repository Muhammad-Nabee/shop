<a href="#">
    <i class="ion-bag"></i>
    <span class="total-pro"><?php echo e($cart['totalQty']); ?></span>
    <span class="my-cart">
            <span>my cart</span>
            <span class="total-price">£<?php echo e($cart['discountPrice']); ?></span>
        </span>
</a>
<ul class="ht-dropdown cart-box-width">
    <?php if(count($cart['items'])<1): ?>
        <li>No Item</li>
    <?php else: ?>
        <li>
            <!-- Cart Box Start -->
            <?php $__currentLoopData = $cart['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $each): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                  $product = $each['item'];
                ?>
                <div class="single-cart-box">
                    <div class="cart-img">
                        <a href="<?php echo e($product['seo_url_slug']); ?>">
                            <?php $__currentLoopData = $product['media']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($loop->first): ?>
                                    <img src="<?php echo e(asset('storage/products/'.$media['media'])); ?>" alt="<?php echo e($product['title']); ?>">
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </a>
                        <span class="pro-quantity"><?php echo e($each['qty'].'X'); ?></span>
                    </div>
                    <div class="cart-content">
                        <h6><a href="<?php echo e($product['seo_url_slug']); ?>"><?php echo e($product['title']); ?> </a></h6>
                        <span class="cart-price">£ <?php echo e($each['discount_price']); ?></span>
                    </div>
                    <a class="del-icone remove-item-from-cart" href="javascript:;" data-id="<?php echo e($product['id']); ?>"><i class="ion-close"></i></a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="cart-footer">
                <ul class="price-content">
                    <li>Subtotal <span>£ <?php echo e($cart['discountPrice']); ?></span></li>
                    <li>Shipping <span>£ 0.00</span></li>
                    <li>Taxes <span>£ 0.00</span></li>
                    <li>Total <span>£ <?php echo e($cart['discountPrice']); ?></span></li>
                </ul>
                <div class="cart-actions text-center">
                    <a class="cart-checkout" href="<?php echo e(asset('checkout')); ?>">Checkout</a>
                </div>
            </div>
            <!-- Cart Footer Inner End -->
        </li>
    <?php endif; ?>
</ul>
<?php /**PATH D:\xampp\htdocs\onlinepharmacyshop.co.uk\shop\resources\views/frontend/components/cartList.blade.php ENDPATH**/ ?>