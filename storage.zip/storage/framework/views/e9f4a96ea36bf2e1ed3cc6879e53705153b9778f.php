

<?php $__env->startSection('title', @$product->seoSetting->meta_title); ?>
<?php $__env->startSection('keywords', @$product->seoSetting->meta_keywords); ?>
<?php $__env->startSection('description', @$product->seoSetting->meta_description); ?>

<?php $__env->startSection('content'); ?>
    <style>
        .star_active {
            color: #f1c40f !important;
        }
        .star_in_active {
            color: #474545 !important;
        }
        span.custom-font-size {
            font-size: 11px;
        }
        .clearfix.add_bottom_10 {
            font-size: 8px !important;
        }
        .rating-box {
            font-size: 25px;
        }
    </style>
    <style type="text/css">
        .hv{
            background-color: #ab8e66!important;
            color:#fff;
        }
        .hv a{

            color:#fff;
        }

        .hv:hover{
            background-color: #122717!important;
            color:#fff;
        }
        .hv:hover a{
            color:#ffffff!important;
        }
        .breadcramp{

        }
        .mt-30{
            margin-top: 100px;
        }

        div.toption{

            position: relative;
            display: flex;
            flex-direction: column;
            min-width: 0;
            word-wrap: break-word;
            background-color: #fff;
            background-clip: border-box;
            border: 1px solid rgba(0,0,0,.125);
            border-radius: .25rem;

        }
        div.toption .card-header{
            background-color: rgb(171, 142, 102);
            color: #fff;
        }
        div.toption .card-body{
            text-align: center;
        }
        div.toption .card-body img{
            height: 120px;
            margin: 15px 0px 15px 0px;
        }
        div.toption .card-body p.shortdescription{
            min-height: 45px;
        }
        div.toption .card-body a{
            margin: 10px 0px 10px 0px;
        }

        .medicine-reviews .fa{
            color: #fdad2c;
        }

        /* field set */
        .dosagediv{
            border: 1px solid rgba(0,0,0,.125);
            border-radius: .25rem;
            overflow:auto;
            padding: 15px 15px;
        }
        /* end field set */


        /*Medicine Navigation Tab */
        .meddescriptionnav{

        }
        .meddescriptionnav .nav-link{
            color: #ab8e66;
        }
        .tab-content{
            border: 1px solid rgba(0,0,0,.125);
            border-top: none;
            padding: 25px 25px;
        }

        .btn-outline-dark-active {
            color: #fff;
            background-color: #212529;
            border-color: #212529;
        }
    </style>
    <!-- Breadcrumb Start -->
    <div class="breadcrumb-area mt-40">
        <div class="container">
            <div class="breadcrumb">
                <ul class="d-flex align-items-center">
                    <li><a href="<?php echo e(asset('/')); ?>">Home</a></li>
                    
                    <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $breadcrumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                         <a href="<?php echo e(url('chemist',$breadcrumb->seo_url_slug)); ?>"><?php echo e($breadcrumb->title); ?></a>
                       </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <li class="active">
                        <a href="javascript:;">
                         <?php echo e($product->title); ?>

                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <!-- Container End -->
    </div>

    <!-- Hidden Field Start -->
    <input type="hidden" id="product_id" name="product_id" value="<?php echo e($product->hash_id); ?>" placeholder="">
    <input type="hidden" name="paginate_number" id="paginate_number" value="0" placeholder="">

    <!-- Hidden Field End   -->
    <!-- Breadcrumb End -->
    <!-- Product Thumbnail Start -->
    <div class="main-product-thumbnail ptb-45">
        <div class="container">
            <div class="thumb-bg">
                <div class="row">
                    <!-- Main Thumbnail Image Start -->
                    <div class="col-lg-5 mb-all-40 pt-4">
                        <!-- Thumbnail Large Image start -->
                        <div class="tab-content">
                            <?php if(count($product->media) > 0): ?>
                                <?php $__currentLoopData = $product->media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div id="thumb<?php echo e($loop->index); ?>" class="tab-pane fade show <?php echo e($loop->first ? 'active' :''); ?>">
                                    <a data-fancybox="images" href="<?php echo e(asset('storage/products/'.$media->media)); ?>">
                                        <img src="<?php echo e(asset('storage/products/'.$media->media)); ?>" class="product-custom-image" alt="<?php echo e(@$product->seoSetting->meta_title); ?>">
                                    </a>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                        <!-- Thumbnail Large Image End -->
                        <!-- Thumbnail Image End -->
                        <div class="product-thumbnail mt-3">
                            <div class="thumb-menu owl-carousel nav tabs-area" role="tablist">
                                <?php $__currentLoopData = $product->media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="active" data-toggle="tab" href="#thumb<?php echo e($loop->index); ?>">
                                    <img src="<?php echo e(asset('storage/products/'.$media->media)); ?>" alt="<?php echo e(@$product->seoSetting->meta_title); ?>"></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <!-- Thumbnail image end -->
                    </div>
                    <!-- Main Thumbnail Image End -->
                    <!-- Thumbnail Description Start -->
                    <div class="col-lg-7 pt-4">
                        <div class="thubnail-desc fix">
                            <h3 class="product-header"><?php echo e($product->title); ?></h3>
                            <?php
                                $regNo = $product->regNo;
                            ?>

                            <?php if(!empty($regNo)): ?>
                            <div class="rating-feedback">
                                <?php if(!empty($regNo->sku)): ?> SKU : <?php echo e($regNo->sku); ?> <?php endif; ?> <?php if(!empty($regNo->pip_code)): ?> | PIP-Code : <?php echo e($regNo->pip_code); ?> <?php endif; ?> <?php if(!empty($regNo->ean)): ?> | EAN : <?php echo e($regNo->ean); ?> <?php endif; ?>
                            </div>
                            <?php endif; ?>

                            <div class="rating-summary fix mtb-10">
                                <div class="product-rating">
                                     <?php for($i = 1; $i <= 5; $i++): ?>
                                        <i class="fa fa-star <?php echo e(($i <= $review_avg) ? 'star_active' : 'star_in_active'); ?>"></i>
                                    <?php endfor; ?>
                                    <?php $countReview = count($product->reviews);  ?>
                                    <span><?php echo e($countReview . ($countReview == 1 ? " review" : " reviews")); ?></span>
                                </div>

                            </div>
                            <div class="pro-price mtb-30">
                                <p class="d-flex align-items-center">
                                    <?php if($product->price != $product->discount_price): ?>
                                        <span class="prev-price">£<?php echo e($product->price); ?></span>
                                    <?php endif; ?>

                                    <span class="price">£<?php echo e($product->discount_price); ?></span>

                                    <?php if($product->price != $product->discount_price): ?>
                                        <span class="saving-price">save <?php echo e(round($product->save_percent)); ?>%</span>
                                    <?php endif; ?>
                                </p>
                            </div>
                            <p class="mb-20 pro-desc-details"><?php echo strip_tags($product->description); ?></p>
                            <?php if($product->stock_level > 0): ?>
                            <div class="box-quantity d-flex">

                                <form action="#">
                                    <select class="form-control" id="product-<?php echo e($product->id); ?>-qty">
                                        <?php $allowed = empty($product->quantity_allowe_to_buy) ? 1 : $product->quantity_allowe_to_buy; ?>
                                        <?php for($i = 1; $i<=$allowed; $i++): ?>
                                            <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                        <?php endfor; ?>
                                    </select>
                                </form>
                                <div class="actions-primary ml-2">
                                    <a href="javascript:;" title="Add To Cart" class="add-item-to-cart" data-id="<?php echo e($product->id); ?>" data-original-title="Add to Cart">Add To Cart</a>
                                </div>
                            </div>
                            <?php endif; ?>

                            <div class="pro-ref mt-15">
                                <p>
                                    <span class="in-stock">
                                        <?php if($product->stock_level > 0): ?>
                                        <i class="ion-checkmark-round"></i>
                                        IN STOCK
                                        <?php else: ?>
                                        <span class="text-danger">Out of Stock</span>
                                        <?php endif; ?>
                                    </span>
                                </p>
                            </div>

                            <div class="socila-sharing mt-25">
                                <ul class="d-flex">
                                    <li>share</li>
                                    <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                    <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                    <li><a href="#"><i class="fa fa-google-plus-official" aria-hidden="true"></i></a></li>
                                    <li><a href="#"><i class="fa fa-pinterest-p" aria-hidden="true"></i></a></li>
                                </ul>
                            </div>
                            <div class="product-policy mt-20">

                            </div>
                        </div>
                    </div>
                    <!-- Thumbnail Description End -->
                </div>
                <!-- Row End -->
            </div>
        </div>
        <!-- Container End -->
    </div>
    <!-- Product Thumbnail End -->
    <!-- Product Thumbnail Description Start -->
    <div class="thumnail-desc pb-45">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <ul class="main-thumb-desc nav tabs-area" role="tablist">
                        <?php $__currentLoopData = $product->descriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $description): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a class="<?php echo e($loop->first ? 'active' : ''); ?>" data-toggle="tab" href="#description<?php echo e($loop->index); ?>"><?php echo e($description->title); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if(count($product->reviews) > 0): ?>

                        <li><a class="<?php echo e(count($product->descriptions)<1 ? 'active' : ''); ?>" data-toggle="tab" href="#review">Reviews</a></li>
                        <?php endif; ?>
                    </ul>
                    <!-- Product Thumbnail Tab Content Start -->
                    <div class="tab-content thumb-content border-default">
                        <?php $__currentLoopData = $product->descriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $description): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div id="description<?php echo e($loop->index); ?>" class="tab-pane fade <?php echo e($loop->first ? 'show active' : ''); ?>">
                            <?php echo $description->description; ?>

                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if(count($product->reviews) > 0): ?>
                       <div id="review" class="tab-pane fade <?php echo e(count($product->descriptions)<1 ? ' show active' : ''); ?>">
                        <!-- Reviews Start -->
                            <div class="review" >
                                <h3 class="mt-0">Customer Reviews (<?php echo e(empty($countReview) ? 0 : $countReview); ?>)</h3>

                                <div id="reviews"></div>
                                <?php if(count($product->reviews) > 0): ?>
                                    <p>
                                        <button type="submit" class="btn btn-info" id="load-more-review"> Load More....</button>
                                    </p>
                                <?php endif; ?>
                            </div>
                       </div>
                    <?php endif; ?>

                    <!-- Product Thumbnail Tab Content End -->

                </div>
            </div>
            <!-- Row End -->
        </div>
        <!-- Container End -->
    </div>
    <!-- Product Thumbnail Description End -->
    <?php if(count($relatedProducts)>0): ?>
    <!-- Realted Products Start Here -->
        <div class="second-featured-products related-pro mt-5 pb-45">
            <div class="container">
                <!-- Post Title Start -->
                <div class="post-title">
                    <h2>Related products</h2>
                </div>
                <!-- Post Title End -->
                <!-- New Pro Tow Activation Start -->
                <div class="featured-pro-active owl-carousel">
                    <!-- Single Product Start -->
                    <?php $__currentLoopData = $relatedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="single-product">
                            <!-- Product Image Start -->
                            <div class="pro-img">
                                <a href="<?php echo e($product->seo_url_slug); ?>">
                                    <?php $__currentLoopData = $product->media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($loop->first): ?>
                                            <img class="primary-img" src="<?php echo e(asset('storage/products/'.$media->media)); ?>" alt="single-product">
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </a>
                                <span class="sticker-new">new</span>
                            </div>
                            <!-- Product Image End -->
                            <!-- Product Content Start -->
                            <div class="pro-content">
                                <div class="pro-info">
                                    <h4><a href="<?php echo e($product->seo_url_slug); ?>"><?php echo e($product->title); ?></a></h4>
                                    <div class="product-rating">
                                    <?php
                                        $review_avg = reviewCalculate($product);
                                    ?>
                                    <?php for($i = 1; $i <= 5; $i++): ?>
                                        <i class="fa fa-star fa-lg <?php echo e(($i <= $review_avg) ? 'star_active' : 'star_in_active'); ?>"></i>
                                    <?php endfor; ?>
                                    </div>
                                    <p><span class="price">£<?php echo e($product->discount_price); ?></span>
                                     <?php if($product->price != $product->discount_price): ?>
                                            <del class="prev-price">£<?php echo e($product->price); ?></del>
                                            <?php endif; ?>
                                        </p>
                                </div>
                                <div class="pro-actions">
                                    <div class="actions-primary">
                                        <a href="javascript:;" data-id="<?php echo e($product->id); ?>" class="add-item-to-cart" title="Add to Cart">Add To Cart</a>
                                    </div>
                                    <div class="actions-secondary">
                                        <a href="<?php echo e($product->seo_url_slug); ?>" title="Details"><i class="fa fa-signal"></i></a>
                                    </div>
                                </div>
                            </div>
                            <!-- Product Content End -->
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
                <!-- New Pro Tow Activation End -->
            </div>
            <!-- Container End -->
        </div>
    <!-- Realated Products End Here -->
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo $__env->make('frontend.components.review_js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Frontend-onlinepharmacyshop\resources\views/frontend/products/show.blade.php ENDPATH**/ ?>