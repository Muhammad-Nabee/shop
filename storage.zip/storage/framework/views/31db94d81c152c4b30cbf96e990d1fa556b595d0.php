
<?php $__env->startSection('title', 'Thank You'); ?>
<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(asset('assets/theme_assets/css/checkout.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
      <div class="main-page-banner ptb-45">
        <div class="container">
            <div class="row">
                    <div class="col-md-8 mt-6 offset-2">
                        <?php echo getPageSection('order-completed-message'); ?>

                    </div>
            </div>

        </div>
        <!-- Container End -->
</div>
   

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Frontend-onlinepharmacyshop\resources\views/frontend/thank_you.blade.php ENDPATH**/ ?>