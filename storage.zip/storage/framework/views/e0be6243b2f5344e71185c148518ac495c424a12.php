<?php if(Session::has('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" id="alert-success" role="alert">
        <span><?php echo Session::get('success'); ?></span>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php endif; ?>
<?php if(Session::has('successEmail')): ?>
    <div class="alert alert-success alert-dismissible fade show" id="alert-success-email" role="alert">
        <span><?php echo Session::get('successEmail'); ?></span>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php endif; ?>
<?php if(Session::has('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show" id="alert-danger" role="alert">
        <span><?php echo Session::get('error'); ?></span>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php endif; ?>
<?php if(Session::has('warn')): ?>
    <div class="alert alert-danger alert-dismissible fade show" id="alert-warn" role="alert">
        <span><?php echo Session::get('warn'); ?></span>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php endif; ?>
<?php if(Session::has('warnEmail')): ?>
    <div class="alert alert-danger alert-dismissible fade show" id="alert-warn-email" role="alert">
        <span><?php echo Session::get('warnEmail'); ?></span>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php endif; ?>
<?php if(count($errors) > 0): ?>
    <div class="alert alert-danger" id="">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\onlinepharmacyshop.co.uk\shop\resources\views/frontend/include/message.blade.php ENDPATH**/ ?>