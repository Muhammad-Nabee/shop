<?php if(count($reviews) > 0): ?>
    <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row">
            <div class="col-lg-8">
                <div class="review_content">
                    <span class="custom-font-size"><?php if($review->reviewPatient): ?>
                        <strong><?php echo e($review->reviewPatient->first_name); ?></strong>
                      <?php endif; ?>
                    </span>
                    <div class="clearfix add_bottom_10">
                        <span class="product-rating">
                            <?php for($i = 1; $i <= 5; $i++): ?>
                                <i class="fa fa-star <?php echo e(($i <= $review->rating) ? 'star_active' : 'star_in_active'); ?>"></i>
                            <?php endfor; ?>

                        </span>
                    </div>
                    <p><?php echo e($review->rating_text); ?></p>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\Frontend-onlinepharmacyshop\resources\views/frontend/components/review_render.blade.php ENDPATH**/ ?>