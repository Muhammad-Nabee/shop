<script src="<?php echo e(asset('assets/js/vendor/jquery-3.6.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/vendor/jquery-migrate-3.3.2.min.js')); ?>"></script>
<!-- Countdown js -->
<script src="<?php echo e(asset('assets/js/jquery.countdown.min.js')); ?>"></script>
<!-- Mobile menu js -->
<script src="<?php echo e(asset('assets/js/jquery.meanmenu.min.js')); ?>"></script>
<!-- ScrollUp js -->
<script src="<?php echo e(asset('assets/js/jquery.scrollUp.js')); ?>"></script>
<!-- Nivo slider js -->
<script src="<?php echo e(asset('assets/js/jquery.nivo.slider.js')); ?>"></script>
<!-- Fancybox js -->
<script src="<?php echo e(asset('assets/js/jquery.fancybox.min.js')); ?>"></script>
<!-- Jquery nice select js -->

<!-- Jquery ui price slider js -->
<script src="<?php echo e(asset('assets/js/jquery-ui.min.js')); ?>"></script>
<!-- Owl carousel -->
<script src="<?php echo e(asset('assets/js/owl.carousel.min.js')); ?>"></script>
<!-- Bootstrap popper js -->
<script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
<!-- Bootstrap js -->
<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
<!-- Plugin js -->
<script src="<?php echo e(asset('assets/js/plugins.js')); ?>"></script>
<!-- Main activaion js -->
<script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>

<script src="<?php echo e(asset('assets/js/mc_scripts/form_validation/dist/jquery.validate.js')); ?>"></script>
<script src="https://ajax.aspnetcdn.com/ajax/jquery.validate/1.15.0/additional-methods.js"></script>


<script src="<?php echo e(asset('assets/js/system/cart.js')); ?>"></script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-sweetalert/1.0.1/sweetalert.min.js" integrity="sha512-MqEDqB7me8klOYxXXQlB4LaNf9V9S0+sG1i8LtPOYmHqICuEZ9ZLbyV3qIfADg2UJcLyCm4fawNiFvnYbcBJ1w==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<?php /**PATH D:\xampp\htdocs\Frontend-onlinepharmacyshop\resources\views/frontend/include/script.blade.php ENDPATH**/ ?>