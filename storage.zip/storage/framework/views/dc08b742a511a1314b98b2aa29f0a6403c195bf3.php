
<!-- Latest jQuery --> 
<script src="<?php echo e(asset('new/assets/js/jquery-3.6.0.min.js')); ?>"></script> 
<!-- popper min js -->
<script src="<?php echo e(asset('new/assets/js/popper.min.js')); ?>"></script>
<!-- Latest compiled and minified Bootstrap --> 
<script src="<?php echo e(asset('new/assets/bootstrap/js/bootstrap.min.js')); ?>"></script> 
<!-- owl-carousel min js  --> 
<script src="<?php echo e(asset('new/assets/owlcarousel/js/owl.carousel.min.js')); ?>"></script> 
<!-- magnific-popup min js  --> 
<script src="<?php echo e(asset('new/assets/js/magnific-popup.min.js')); ?>"></script> 
<!-- waypoints min js  --> 
<script src="<?php echo e(asset('new/assets/js/waypoints.min.js')); ?>"></script> 
<!-- parallax js  --> 
<script src="<?php echo e(asset('new/assets/js/parallax.js')); ?>"></script> 
<!-- countdown js  --> 
<script src="<?php echo e(asset('new/assets/js/jquery.countdown.min.js')); ?>"></script> 
<!-- imagesloaded js --> 
<script src="<?php echo e(asset('new/assets/js/imagesloaded.pkgd.min.js')); ?>"></script>
<!-- isotope min js --> 
<script src="<?php echo e(asset('new/assets/js/isotope.min.js')); ?>"></script>
<!-- jquery.dd.min js -->
<script src="<?php echo e(asset('new/assets/js/jquery.dd.min.js')); ?>"></script>
<!-- slick js -->
<script src="<?php echo e(asset('new/assets/js/slick.min.js')); ?>"></script>
<!-- elevatezoom js -->
<script src="<?php echo e(asset('new/assets/js/jquery.elevatezoom.js')); ?>"></script>
<!-- scripts js --> 
<script src="<?php echo e(asset('new/assets/js/scripts.js')); ?>"></script>

<script src="<?php echo e(asset('assets/js/mc_scripts/form_validation/dist/jquery.validate.js')); ?>"></script>
<script src="https://ajax.aspnetcdn.com/ajax/jquery.validate/1.15.0/additional-methods.js"></script>


<script src="<?php echo e(asset('assets/js/system/cart.js')); ?>"></script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-sweetalert/1.0.1/sweetalert.min.js" integrity="sha512-MqEDqB7me8klOYxXXQlB4LaNf9V9S0+sG1i8LtPOYmHqICuEZ9ZLbyV3qIfADg2UJcLyCm4fawNiFvnYbcBJ1w==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<?php /**PATH D:\xampp\htdocs\tdprojects\shop\resources\views/frontend/include/script.blade.php ENDPATH**/ ?>