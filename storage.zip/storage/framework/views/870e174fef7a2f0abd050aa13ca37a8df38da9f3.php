<!-- Fontawesome css -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/font-awesome.min.css')); ?>">
<!-- Ionicons css -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/ionicons.min.css')); ?>">
<!-- Nice select css -->

<!-- Jquery fancybox css -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/jquery.fancybox.css')); ?>">
<!-- Jquery ui price slider css -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/jquery-ui.min.css')); ?>">
<!-- Meanmenu css -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/meanmenu.min.css')); ?>">
<!-- Nivo slider css -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/nivo-slider.css')); ?>">
<!-- Owl carousel css -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/owl.carousel.min.css')); ?>">
<!-- Bootstrap css -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
<!-- Custom css -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/default.css')); ?>">
<!-- Main css -->
<link rel="stylesheet" href="<?php echo e(asset('assets/style.css')); ?>">
<!-- Home tow color css -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/orange-color.css')); ?>">
<!-- Responsive css -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/responsive.css')); ?>">

<!-- Modernizer js -->
<script src="<?php echo e(asset('assets/js/vendor/modernizr-3.5.0.min.js')); ?>"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-sweetalert/1.0.1/sweetalert.css" integrity="sha512-f8gN/IhfI+0E9Fc/LKtjVq4ywfhYAVeMGKsECzDUHcFJ5teVwvKTqizm+5a84FINhfrgdvjX8hEJbem2io1iTA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<style>
    .error {
        color: red;
    }
    .star_active {
        color: #f1c40f !important;
    }
    .star_in_active {
        color: #474545 !important;
    }
    span.custom-font-size {
        font-size: 11px;
    }
    .clearfix.add_bottom_10 {
        font-size: 8px !important;
    }
    .rating-box {
        font-size: 25px;
    }
</style>
<?php /**PATH D:\xampp\htdocs\onlinepharmacyshop.co.uk\shop\resources\views/frontend/include/style.blade.php ENDPATH**/ ?>