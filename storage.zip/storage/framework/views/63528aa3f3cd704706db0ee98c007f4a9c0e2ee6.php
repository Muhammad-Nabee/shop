
<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('content'); ?>

<!-- START SECTION BANNER -->
<div class="banner_section slide_wrap shop_banner_slider staggered-animation-wrap">
    <div id="carouselExampleControls" class="carousel slide carousel-fade light_arrow" data-bs-ride="carousel">
        <div class="carousel-inner">

       <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="carousel-item <?php if($loop->index == 0): ?> active <?php endif; ?> background_bg" data-img-src="<?php echo e(url('storage/banner/'.$banner->image)); ?>">
                <div class="banner_slide_content banner_content_inner">
                  <div class="container">
                      <div class="row">
                            <div class="col-lg-6 col-md-8 col-sm-9 col-10">
                                <div class="banner_content2">
                                  <?php echo $banner->description; ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

         
        </div>
        <ol class="carousel-indicators indicators_style2">
            <li data-bs-target="#carouselExampleControls" data-bs-slide-to="0" class="active"></li>
            <li data-bs-target="#carouselExampleControls" data-bs-slide-to="1"></li>
            <li data-bs-target="#carouselExampleControls" data-bs-slide-to="2"></li>
        </ol>
    </div>
</div>
<!-- END SECTION BANNER -->

<!-- END MAIN CONTENT -->
<div class="main_content">

<!-- START SECTION SHIPPING INFO -->
<div class="section small_pb">
    <div class="container">
        <div class="row g-0">
            <div class="col-lg-3 col-sm-6"> 
                <div class="icon_box icon_box_style3">
                    <div class="icon">
                        <i class="flaticon-shipped"></i>
                    </div>
                    <div class="icon_box_content">
                        <h6>Free Delivery</h6>
                        <p>Worldwide</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6"> 
                <div class="icon_box icon_box_style3">
                    <div class="icon">
                        <i class="flaticon-money-back"></i>
                    </div>
                    <div class="icon_box_content">
                        <h6>Money Returns</h6>
                        <p>30 Days money return</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6"> 
                <div class="icon_box icon_box_style3">
                    <div class="icon">
                        <i class="flaticon-support"></i>
                    </div>
                    <div class="icon_box_content">
                        <h6>27/4 Online Support</h6>
                        <p>Customer Support</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6"> 
                <div class="icon_box icon_box_style3">
                    <div class="icon">
                        <i class="flaticon-lock"></i>
                    </div>
                    <div class="icon_box_content">
                        <h6>Payment Security</h6>
                        <p>Safe Payment</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- START SECTION SHIPPING INFO -->

<!-- START SECTION SHOP -->
<div class="section small_pt pb_20">
  <div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="heading_s3 text-center">
                <h2>Exclusive Products</h2>
            </div>
            <div class="small_divider clearfix"></div>
        </div>
    </div>
        <div class="row shop_container">
             <?php $__currentLoopData = $featuredProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 col-md-4 col-6">
                    <div class="product_box text-center">
                        <div class="product_img">
                        <?php $__currentLoopData = $product->media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($loop->first): ?>
                                <a href="shop-product-detail.html">
                                    <img src="<?php echo e(asset('storage/products/'.$media->media)); ?>" alt="furniture_img2">
                                </a>
                            <?php endif; ?>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="product_info">
                            <h6 class="product_title"><a href="<?php echo e($product->seo_url_slug); ?>"><?php echo e($product->title); ?></a></h6>
                            <div class="product_price">
                                <span class="price">AED <?php echo e($product->discount_price); ?></span>
                                <?php if($product->price != $product->discount_price): ?>
                                    <del class="prev-price">AED <?php echo e($product->price); ?></del>
                                <?php endif; ?>
                            </div>
                            <?php
                                $countReview = count($product->reviews);  
                                $review_avg = reviewCalculate($product);
                            ?>
                            <div class="rating_wrap">
                                <div class="rating">
                                    <div class="product_rate" style="width:<?php echo e($review_avg*20); ?>%"></div>
                                </div>
                                <span class="rating_num">(<?php echo e($countReview); ?>)</span>
                            </div>
                            

                            <div class="add-to-cart">
                                <?php if($product->stock_level < 1): ?>
                                    <a href="javascript:;" class="btn btn-fill-out btn-radius"><i class="icon-basket-loaded"></i>Out of Stock</a>
                                <?php else: ?>
                                    <a href="javascript:;" class="btn btn-fill-out btn-radius add-item-to-cart" data-id="<?php echo e($product->id); ?>"><i class="icon-basket-loaded"></i>Add to cart </a>
                                <?php endif; ?>
                            </div>

                        </div>
                    </div>
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div> 
    </div>
</div>
<!-- END SECTION SHOP -->

<!-- START SECTION BANNER --> 
<div class="section pb_20 small_pt">
  <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="heading_s3 text-center">
                    <h2>Top Categories</h2>
                </div>
                <div class="small_divider clearfix"></div>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $pageCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                  <div class="single_banner">
                      <img src="<?php echo e(asset('storage/category/'.$pCategory->image_1)); ?>" alt="furniture_banner1">
                        <div class="fb_info">
                             <a href="<?php echo e(route('category', ['slug' => $pCategory->seo_url_slug])); ?>" class="single_bn_link">
                              <h5 class="single_bn_title1"><?php echo e($pCategory->title); ?></h5>
                            </a>
                                                   
                         </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>
    </div>
</div>
<!-- END SECTION BANNER -->

<!-- START SECTION SHOP -->

<!-- END SECTION SHOP -->

<!-- START SECTION INSTAGRAM IMAGE -->

<!-- END SECTION INSTAGRAM IMAGE --> 

<!-- START SECTION CLIENT LOGO -->
<div class="section small_pt">
  <div class="container">
        <div class="row">
          <div class="col-12">
              <div class="client_logo carousel_slider owl-carousel owl-theme" data-dots="false" data-margin="30" data-loop="true" data-autoplay="true" data-responsive='{"0":{"items": "2"}, "480":{"items": "3"}, "767":{"items": "4"}, "991":{"items": "5"}}'>
               <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item">
                  <div class="cl_logo">
                      <img src="<?php echo e(asset('storage/brands/'.$brand->logo)); ?>" alt="cl_logo"/>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- END SECTION CLIENT LOGO -->

</div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('frontend.master_new', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\tdprojects\shop\resources\views/frontend/home_new.blade.php ENDPATH**/ ?>