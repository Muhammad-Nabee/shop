

<?php $__env->startSection('title', @$product->seoSetting->meta_title); ?>
<?php $__env->startSection('keywords', @$product->seoSetting->meta_keywords); ?>
<?php $__env->startSection('description', @$product->seoSetting->meta_description); ?>

<?php $__env->startSection('content'); ?>

    <!-- START SECTION BREADCRUMB -->
<div class="breadcrumb_section bg_gray page-title-mini">
    <div class="container"><!-- STRART CONTAINER -->
        <div class="row align-items-center">
            <div class="col-md-6">
                <div class="page-title">
                    <h1>Product Detail</h1>
                </div>
            </div>
            <div class="col-md-6">
                <ol class="breadcrumb justify-content-md-end">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $breadcrumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="breadcrumb-item">
                         <a href="<?php echo e(url('chemist',$breadcrumb->seo_url_slug)); ?>"><?php echo e($breadcrumb->title); ?></a>
                       </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <li class="breadcrumb-item active"> <?php echo e($product->title); ?></li>
                </ol>
            </div>
        </div>
    </div><!-- END CONTAINER-->
</div>
<!-- END SECTION BREADCRUMB -->

<!-- START MAIN CONTENT -->
<div class="main_content">

<!-- START SECTION SHOP -->
<div class="section">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6 mb-4 mb-md-0">
              <div class="product-image">
                    <div class="product_img_box">
                        <img id="product_img" src='<?php echo e(asset('storage/products/'.$product->media[0]->media)); ?>' data-zoom-image="<?php echo e(asset('storage/products/'.$product->media[0]->media)); ?>" alt="product_img1" />
                        <a href="#" class="product_img_zoom" title="Zoom">
                            <span class="linearicons-zoom-in"></span>
                        </a>
                    </div>
                    <div id="pr_item_gallery" class="product_gallery_item slick_slider" data-slides-to-show="4" data-slides-to-scroll="1" data-infinite="false">

                        <?php if(count($product->media) > 0): ?>
                            <?php $__currentLoopData = $product->media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <div class="item">
                                    <a href="#" class="product_gallery_item <?php echo e($loop->first ? 'active' :''); ?>" data-image="<?php echo e(asset('storage/products/'.$media->media)); ?>" data-zoom-image="<?php echo e(asset('storage/products/'.$media->media)); ?>">
                                        <img src="<?php echo e(asset('storage/products/'.$media->media)); ?>" alt="product_small_img1" alt="<?php echo e(@$product->seoSetting->meta_title); ?>"/>
                                    </a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

               
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-6">
                <div class="pr_detail">
                    <div class="product_description">
                        <h4 class="product_title"><?php echo e($product->title); ?></h4>
                        <div class="product_price">
                            <?php if($product->price != $product->discount_price): ?>
                               <del>AED<?php echo e($product->discount_price); ?></del>
                            <?php endif; ?>
                            <span class="price">AED<?php echo e($product->price); ?></span>
                            <?php if($product->price != $product->discount_price): ?>
                                <div class="on_sale"> <span>save <?php echo e(round($product->save_percent)); ?>%</span>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="rating_wrap">
                        <?php $countReview = count($product->reviews);  ?>
                        <?php
                            $review_avg = reviewCalculate($product);
                            $review_avg = $review_avg * 20;
                        ?>
                        
                        <div class="rating">
                            <div class="product_rate" style="width:<?php echo e($review_avg); ?>%"></div>
                        </div>
                        <span class="rating_num">(<?php echo e($countReview); ?>)</span>
                        </div>
                        <div class="pr_desc">
                            <p><?php echo e($product->description); ?>.</p>
                        </div>
                     
                     
                    </div>
                    <hr />
                    <div class="cart_extra">
                        <div class="cart-product-quantity">
                            <div class="quantity">
                                <input type="button" value="-" class="minus">
                                <input type="text" name="quantity" value="1" title="Qty" class="qty" size="50" id="product-<?php echo e($product->id); ?>-qty">
                                <input type="button" value="+" class="plus">
                            </div>
                        </div>
                        <div class="cart_btn">
                            <button class="btn btn-fill-out btn-addtocart add-item-to-cart" data-id="<?php echo e($product->id); ?>"  type="button"><i class="icon-basket-loaded"></i> Add to cart</button>
                         
                        </div>
                    </div>
                    <hr />
                    <ul class="product-meta">
                         <?php if(!empty($regNo->sku)): ?> <li>SKU: : <?php echo e($regNo->sku); ?> </a></li> <?php endif; ?>
                    </ul>
                    
                    <div class="product_share">
                        <span>Share:</span>
                        <ul class="social_icons">
                            <li><a href="#"><i class="ion-social-facebook"></i></a></li>
                            <li><a href="#"><i class="ion-social-twitter"></i></a></li>
                            <li><a href="#"><i class="ion-social-googleplus"></i></a></li>
                            <li><a href="#"><i class="ion-social-youtube-outline"></i></a></li>
                            <li><a href="#"><i class="ion-social-instagram-outline"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="large_divider clearfix"></div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="tab-style3">
                    <ul class="nav nav-tabs" role="tablist">
                     <?php $__currentLoopData = $product->descriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $description): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e($loop->first ? 'active' : ''); ?>" id="Description-tab<?php echo e($loop->index); ?>" data-bs-toggle="tab" href="#Description<?php echo e($loop->index); ?>" role="tab" aria-controls="Description" aria-selected="true"><?php echo e($description->title); ?></a>
                        </li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       <?php if(count($product->reviews) > 0): ?>
                          <li class="nav-item">
                              <a class="nav-link <?php echo e(count($product->descriptions)<1 ? 'active' : ''); ?>" id="Reviews-tab" data-bs-toggle="tab" href="#Reviews" role="tab" aria-controls="Reviews" aria-selected="false">Reviews (<?php echo e(count($product->reviews)); ?>)</a>
                           </li>
                        <?php endif; ?>
                    </ul>
                    <div class="tab-content shop_info_tab">
                        <?php $__currentLoopData = $product->descriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $description): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <div class="tab-pane fade <?php echo e($loop->first ? 'show active' : ''); ?>" id="Description<?php echo e($loop->index); ?>" role="tabpanel" aria-labelledby="Description-tab">
                             <?php echo $description->description; ?>

                          </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if(count($product->reviews) > 0): ?>
                            <div class="tab-pane fade" id="Reviews" role="tabpanel" aria-labelledby="Reviews-tab">
                                <div class="comments">
                                    <h5 class="product_tab_title"><?php echo e(count($product->reviews)); ?> Review For <span><?php echo e($product->title); ?></span></h5>
                                    <ul class="list_none comment_list mt-4">
                                        <li>
                                            <div class="comment_img">
                                                <img src="<?php echo e(asset('assets/images/user1.jpg')); ?>" alt="user1"/>
                                            </div>
                                            <div class="comment_block">
                                                 <?php 
                                                   $rate_pro = $product->review->rating*20;
                                                 ?>
                                                <div class="rating_wrap">
                                                    <div class="rating">
                                                        <div class="product_rate" style="width:<?php echo e($rate_pro); ?>%"></div>
                                                    </div>
                                                </div>
                                                <p class="customer_meta">
                                                    <span class="review_author"><?php echo e($product->review->reviewPatient->first_name); ?></span>
                                                    <span class="comment-date"><?php echo e($product->review->reviewPatient->created_at); ?></span>
                                                </p>
                                                <div class="description">
                                                    <?php echo e($product->review->rating_text); ?>

                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                          
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="small_divider"></div>
                <div class="divider"></div>
                <div class="medium_divider"></div>
            </div>
        </div>
        <?php if(count($relatedProducts)>0): ?>
            <div class="row">
                <div class="col-12">
                    <div class="heading_s1">
                        <h3>Releted Products</h3>
                    </div>
                    <div class="releted_product_slider carousel_slider owl-carousel owl-theme" data-margin="20" data-responsive='{"0":{"items": "1"}, "481":{"items": "2"}, "768":{"items": "3"}, "1199":{"items": "4"}}'>
                    <?php $__currentLoopData = $relatedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item">
                        <div class="product_box text-center">
                            <div class="product_img">
                            <?php $__currentLoopData = $product->media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($loop->first): ?>
                                    <a href="shop-product-detail.html">
                                        <img src="<?php echo e(asset('storage/products/'.$media->media)); ?>" alt="furniture_img2">
                                    </a>
                                <?php endif; ?>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="product_info">
                                <h6 class="product_title"><a href="<?php echo e($product->seo_url_slug); ?>"><?php echo e($product->title); ?></a></h6>
                                <div class="product_price">
                                    <span class="price">AED <?php echo e($product->discount_price); ?></span>
                                    <?php if($product->price != $product->discount_price): ?>
                                        <del class="prev-price">AED <?php echo e($product->price); ?></del>
                                    <?php endif; ?>
                                </div>
                              
                                <?php
                                    $countReview = count($product->reviews);  
                                    $review_avg = reviewCalculate($product);
                                    $review_avg = $review_avg * 20;
                                ?>
                          
                                <div class="rating_wrap">
                                    <div class="rating">
                                        <div class="product_rate" style="width:<?php echo e($review_avg); ?>%"></div>
                                    </div>
                                    <span class="rating_num">(<?php echo e($countReview); ?>)</span>
                                </div>

                                

                                <div class="add-to-cart">
                                    <?php if($product->stock_level < 1): ?>
                                        <a href="javascript:;" class="btn btn-fill-out btn-radius"><i class="icon-basket-loaded"></i>Out of Stock</a>
                                    <?php else: ?>
                                        <a href="javascript:;" class="btn btn-fill-out btn-radius add-item-to-cart" data-id="<?php echo e($product->id); ?>"><i class="icon-basket-loaded"></i>Add to cart </a>
                                    <?php endif; ?>
                                </div>

                            </div>
                        </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
<!-- END SECTION SHOP -->
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\tdprojects\shop\resources\views/frontend/products/show_new.blade.php ENDPATH**/ ?>